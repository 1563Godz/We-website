import pandas as pd  # ใช้สำหรับจัดการข้อมูลในรูปแบบ DataFrame
from sklearn.ensemble import RandomForestClassifier  # โมเดล Random Forest สำหรับงาน classification
from sklearn.model_selection import train_test_split  # สำหรับแบ่งข้อมูล train/test
from pathlib import Path  # ใช้จัดการ path ของไฟล์ (ไม่ได้ใช้ในโค้ดนี้)
from sklearn.feature_extraction.text import TfidfVectorizer  # แปลงข้อความเป็นเวกเตอร์ตัวเลขด้วย TF-IDF
from sklearn.preprocessing import LabelEncoder  # แปลง label (ข้อความ) เป็นตัวเลข
from sklearn.model_selection import cross_val_score  # สำหรับ cross-validation (ไม่ได้ใช้ในโค้ดนี้)

dataset='IMDB Dataset.csv'  # กำหนดชื่อไฟล์ dataset
dataset = pd.read_csv(dataset)  # โหลดข้อมูลจากไฟล์ CSV

vector = TfidfVectorizer(max_features = 10000)  # สร้าง TF-IDF vectorizer โดยจำกัด feature สูงสุด 10,000
Label = LabelEncoder()  # สร้าง label encoder

x = vector.fit_transform(dataset['review'])  # แปลงคอลัมน์ review เป็นเวกเตอร์ตัวเลข
y = Label.fit_transform(dataset['sentiment'])  # แปลงคอลัมน์ sentiment เป็นตัวเลข (0/1)

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2 , random_state = 0)  # แบ่งข้อมูล train/test

model = RandomForestClassifier(n_estimators = 100, n_jobs=-1)  # สร้างโมเดล Random Forest จำนวน 100 ต้นไม้
model.fit(x_train, y_train)  # ฝึกโมเดลด้วยข้อมูล train

data = input('ป้อนมา : ')  # รับข้อความจากผู้ใช้
data_t = vector.transform([data])  # แปลงข้อความที่รับมาเป็นเวกเตอร์
scores = model.predict(data_t)  # ทำนายผลลัพธ์ (0/1)

if scores == 1:
  print('บวก')  # ถ้าผลเป็น 1 แสดงว่าเป็น sentiment บวก
elif scores == 0:
  print('ลบ')  # ถ้าผลเป็น 0 แสดงว่าเป็น sentiment ลบ